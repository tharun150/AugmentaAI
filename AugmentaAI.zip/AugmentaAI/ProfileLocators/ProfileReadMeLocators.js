

const {profileData} = require('../sampleData/ProfileReadMeData')
class locators{
    constructor(page){
        this.page=page;
        this.titleNameInput = page.locator('#title-name');
        this.subtitleInput = page.locator('#subtitle');
        this.currentWorkInput = page.locator('#currentWork');
        this.currentWorkLinkInput = page.locator('#currentWork-link');
        this.collaborateOnInput = page.locator('#collaborateOn');
        this.collaborateOnLinkInput = page.locator('#collaborateOn-link');
        this.instagramInput = page.locator('#instagram');
        this.githubInput = page.locator('#github');
        this.topLanguagesCheckbox = page.locator('#top-languages');
        this.topLanguagesOpenBtn = page.locator('#top-languages-open-btn');
        this.topLanguageTitleColor = page.locator('#top-lang-title-color');
        this.generateReadmeButton = page.locator("//div[contains(text(),'Generate README')]");
        this.generatedMarkup = page.locator('#markdown-content');
        this.githubStarsCount = page.locator('.github-count');
        this.fileInput = page.locator('input[type="file"]');
        this.restoreButton = page.locator("//button[contains(text(),'Restore')]");
        this.funFactPrefix = page.locator('#funFact-prefix');
        this.currentWorkField = page.locator('#currentWork');
        
    }
    async enterTitleName() {
        await this.titleNameInput.fill(profileData.titleName);
      }
      async modifySubtitle() {
        await this.subtitleInput.fill(profileData.subtitleText);
      }

      async addProjectDetails() {
        await this.currentWorkInput.fill(profileData.currentWork.projectName);
        await this.currentWorkLinkInput.fill(profileData.currentWork.projectLink);
        await this.collaborateOnInput.fill(profileData.collaborateOn.projectName);
        await this.collaborateOnLinkInput.fill(profileData.collaborateOn.projectLink);
      }

      async fillSocialDetails() {
        await this.instagramInput.fill(profileData.social.instagram);
        await this.githubInput.fill(profileData.social.github);
      }
      async clickGenerateReadme() {
        await this.generateReadmeButton.click({ force: true });
      }
}

module.exports=locators;