// @ts-nocheck
const { test, expect } = require("@playwright/test");
const { beforeEach } = require("node:test");
const { chromium } = require("playwright");
const {profileData} = require('../sampleData/ProfileReadMeData')
const PageLocators = require('../ProfileLocators/ProfileReadMeLocators')
const utils = require('../utils');
test.describe("Interview Tasks", () => {
  test.beforeEach("Navigate to URL", async ({ page }) => {
    await page.goto("https://rahuldkjain.github.io/gh-profile-readme-generator/");
  });

  // running it on multiple browsers so there will be 9 test cases as i'm running it on three different browsers in config file
  test("Scenario - 1", async ({ page }) => {
    const pageLocators = new PageLocators(page);
    await pageLocators.enterTitleName();
    await pageLocators.modifySubtitle();

    await pageLocators.addProjectDetails();
    for (const skill of profileData.skills) {
      await page.click(`#${skill.toLowerCase()}`, { force: true });// tried without force:true but the page isn't responsive for that
    }
    await pageLocators.fillSocialDetails();
    await page.click("#top-languages", { force: true });
    await page.click("#top-languages-open-btn");
    await page.evaluate(() => {
      const colorInput = document.querySelector("#top-lang-title-color");
      colorInput.value = "#52ebdb"; // Change the color to RGB (52, 235, 219) in hex
    });
    await pageLocators.clickGenerateReadme();    
    const generatedMarkup = await page.textContent("#markdown-content");
      expect(generatedMarkup).toContain(profileData.subtitleText);
      expect(generatedMarkup).toContain(profileData.skills[4]);
  });

  test("Scenario - 2", async ({ page }) => {
    await page.waitForSelector(".github-count"); // Ensure the element is visible

    // Extracting  the star count from the implemented page and making sure the value is truthy other than zero
    const starsOnImplementedPageHandle = await page.waitForFunction(() => {
      const starElement = document.querySelector(".github-count");
      const count = starElement ? parseInt(starElement.textContent) : 0;
      return count 
    }, { timeout: 10000 }); // Timeout after 10 seconds if the value doesn't change
  
    const starsOnImplementedPage = await starsOnImplementedPageHandle.jsonValue();
    console.log("Stars on implemented page: ", starsOnImplementedPage);
  
    // Navigate to GitHub page and get the star count
    const githubPage = await page.context().newPage();
    await githubPage.goto("https://github.com/rahuldkjain/github-profile-readme-generator"); // GitHub repo URL
    await githubPage.waitForLoadState(); // Ensure the page has loaded
  
    const ariaLabelOnGitPage = await githubPage.getAttribute("#repo-stars-counter-star", "aria-label");
    const starCountOnGitPage = ariaLabelOnGitPage.match(/\d+/)[0]; // Extract the first number
    console.log(starCountOnGitPage);
  
    // Compare the extracted star counts with string for proper comparision
    expect(starsOnImplementedPage.toString()).toBe(starCountOnGitPage);

  });

  test('Scenario -3',async({ page })=>{    
    const Utils = new utils();
    
    await Utils.scrollIntoView(page, 'input[type="file"]');
    await page.locator('input[type="file"]').setInputFiles('sampleData/data.json');
    await page.click("//button[contains(text(),'Restore')]",{force: true});

  await Utils.scrollIntoView(page, '#funFact-prefix');
    expect(await page.inputValue('#funFact-prefix')).toContain('Modified Facts');
    
  await Utils.scrollIntoView(page, '#currentWork');
    expect(await page.inputValue('#currentWork')).toBe('project name');

  });

});