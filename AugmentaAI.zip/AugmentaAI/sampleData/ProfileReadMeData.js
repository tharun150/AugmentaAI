export const profileData = {
  "titleName": "Sandeep Reddy",
  "subtitleText": "Film Maker",
  "currentWork": {
    "projectName": "Arjun Reddy",
    "projectLink": "https://en.wikipedia.org/wiki/Arjun_Reddy"
  },
  "collaborateOn": {
    "projectName": "Super Star",
    "projectLink": "https://en.wikipedia.org/wiki/Mahesh_Babu"
  },
  "skills": ["C", "Cplusplus", "AWS", "Docker", "cypress", "Selenium"],
  "social": {
    "instagram": "urstrulymahesh",
    "github": "brian-mann"
  }
}
