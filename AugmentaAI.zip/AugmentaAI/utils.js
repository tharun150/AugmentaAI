  class utils{
    async scrollIntoView(page, locator) {
    await page.evaluate((selector) => {
      document.querySelector(selector).scrollIntoView();
    }, locator);
  }
  }
module.exports = utils;
